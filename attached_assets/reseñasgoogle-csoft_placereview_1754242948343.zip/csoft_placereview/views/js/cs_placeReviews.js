/*
 * csoft_instagramfeeds_pro front-end module version 1.1.1 for Prestashop 1.6, 1.7
 * Support contact : prestashop@comonsoft.com.
 *
 * NOTICE OF LICENSE
 *
 * This source file is the property of Com'onSoft
 * that is bundled with this package.
 * It is also available through the world-wide-web at this URL:
 * https://boutique.comonsoft.com/
 *
 * @category  front-end
 * @package   csoft_instagramfeeds_pro
 * @author    Com'onSoft (http://www.comonsoft.com/)
 * @copyright 2016-2020 Com'onSoft and contributors
 * @version   1.1.1
 */

var windowWidth = $(window).width();
var numberOfVisibleSlides;
var margin;
var cs_autoSlide = false;

if(csoft_placereview_js.cs_slideAuto){
	cs_autoSlide = true;
}

if (windowWidth < 420) {
	numberOfVisibleSlides = 1;
	margin = 0;
} else if (windowWidth < 767) {
	numberOfVisibleSlides = 2;
	margin = 15
} else {
	numberOfVisibleSlides = 5;
	margin = 30
}
$(document).ready(function()
{
	if( $('#bxslider-placeReviews').length ) {
		$('#bxslider-placeReviews').bxSlider({
				minSlides: 3,
				maxSlides: numberOfVisibleSlides,
				slideWidth: 380,
				slideMargin: margin,
				pager: false,
				nextText: '<i class="material-icons">navigate_next</i>',
				prevText: '<i class="material-icons">navigate_before</i>',
				moveSlides:1,
				infiniteLoop:true,
				hideControlOnEnd: false,
				auto: cs_autoSlide,
				pause: 2000
		});
	}
});