<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

class csoft_placereview extends Module implements WidgetInterface
{
    const cVERIFYPLACEID = 0;
    const cGETREVIEWS = 1;
    const cFINDPLACEID = 2;

    public $templateCsoftPlaceReviews = 'module:csoft_placereview/views/templates/widget/csoft_placeReviews.tpl';
    public $place_id = '';
    public $module_review_path ='';
    public $module_controller_url ='';
    public $product_shop_id = 0;


    public function __construct()
    {
        $this->name = 'csoft_placereview';
        $this->tab = 'front_office_features';
        $this->version = '1.2.0';
        $this->author = 'ComonSoft';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.7',
        ];
        $this->bootstrap = true;

        $this->module_review_path = _PS_MODULE_DIR_ . '/' . $this->name . '/views/templates/admin/post-review-modal.tpl';
        $this->module_controller_url = __PS_BASE_URI__ . 'module/' . $this->name . '/AddModuleReviews';
        $this->product_shop_id = 43;
        $this->controllers = array('AddModuleReviews');


        $this->displayName = $this->l('Google place reviews');
        $this->description = $this->l('This module shows your google reviews in your shop by a slider.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall Google place reviews module?');

        parent::__construct();

        if (!Configuration::get('CSOFT_PLACEREVIEW_KEY')) {
            $this->warning = $this->l('Please configure the module to display reviews.');
        }
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return (parent::install()

            && Configuration::updateValue('CSOFT_PLACEREVIEW_RATE', true)
            && Configuration::updateValue('CSOFT_PLACEREVIEW_PERIODICITY', true)
            && Configuration::updateValue('CSOFT_PLACEREVIEW_TITLE', true)
            && Configuration::updateValue('CSOFT_PLACEREVIEW_CACHE_CONFIG', 1)
            && Configuration::updateValue('CSOFT_PLACEREVIEW_FONT_CHOICE', 1)
            && Configuration::updateValue('CSOFT_PLACEREVIEW_SLIDE_AUTO', 0)
            && Configuration::updateValue('CSOFT_PLACEREVIEW_FILTER', 0)

            && $this->registerHook('displayHome')
            && $this->registerHook('displayHeader')
            && $this->registerHook('actionFrontControllerSetMedia')
            && $this->registerHook('displayBackOfficeHeader')
        );
    }
    public function uninstall()
    {
        return (parent::uninstall()
            && Configuration::deleteByName('CSOFT_PLACEREVIEW_KEY')
            && Configuration::deleteByName('CSOFT_PLACEREVIEW_PLACE_ID')
            && Configuration::deleteByName('CSOFT_PLACEREVIEW_PERIODICITY')
            && Configuration::deleteByName('CSOFT_PLACEREVIEW_RATE')
            && Configuration::deleteByName('CSOFT_PLACEREVIEW_TITLE')
            && Configuration::deleteByName('CSOFT_PLACEREVIEW_CACHE_CONFIG')
            && Configuration::deleteByName('CSOFT_PLACEREVIEW_FONT_CHOICE')
            && Configuration::deleteByName('CSOFT_PLACEREVIEW_SLIDE_AUTO')
            && Configuration::deleteByName('CSOFT_PLACEREVIEW_FILTER')

        );
    }

    // WIDGET
    /**
     * render Widget.
     *
     * return from api reviews
     * 
     * result[
     *     name
     *     rating
     *     reviews[
     *         author_name
     *         author_url
     *         language
     *         profile_photo_url
     *         rating
     *         relative_time_description
     *         text
     *         time
     *     ]
     * ]
     * status
     * 
     * @param string $hookName is for the switch case
     * @param array $configuration
     *
     * @return $template;
     */
    public function renderWidget($hookName, array $configuration)
    {
        $template = '';

        if (Module::isEnabled('csoft_placereview') && Configuration::get('CSOFT_PLACEREVIEW_KEY')) {
            $error = false;
            if (!$this->isCached($this->templateCsoftPlaceReviews, $this->cacheDuration())) {
                $reviews = $this->getWidgetVariables($hookName, $configuration);
                if ($reviews['result'] !== false && isset($reviews['result']['reviews'])) {
                    $this->smarty->assign($reviews);
                } else {
                    $error = true;
                }
				$template = '<!-- no cache -->';
            }

            if ($error == false) {
                $template .= $this->fetch(
                    $this->templateCsoftPlaceReviews,
                    $this->cacheDuration()
                );
            }
        }

        return $template;
    }

    /**
     * Get widget variables.
     *
     * @param string $apiType is for the switch case
     * @param string $place_id is determinated with api key and the global address
     * @param string $apikey is corresponding to the google api key
     * @param string $globalAdress is determinated with prestashop parameter.
     *
     * @return array with result rate period place_id configuration for smarty;
     */
    public function getWidgetVariables($hookName, array $configuration)
    {
        return [
            'result'        => $this->getGoogleReviews((string) Configuration::get('CSOFT_PLACEREVIEW_KEY'), Configuration::get('CSOFT_PLACEREVIEW_PLACE_ID')),
            'rate'          => Configuration::get('CSOFT_PLACEREVIEW_RATE'),
            'period'        => Configuration::get('CSOFT_PLACEREVIEW_PERIODICITY'),
            'place_id'      => Configuration::get('CSOFT_PLACEREVIEW_PLACE_ID'),
            'title'         => Configuration::get('CSOFT_PLACEREVIEW_TITLE'),
            'font_choice'   => Configuration::get('CSOFT_PLACEREVIEW_FONT_CHOICE'),
            'cs_slideAuto'  => Configuration::get('CSOFT_PLACEREVIEW_SLIDE_AUTO')
        ];
    }

    // FIN WIDGET

    public function getContent()
    {
        $place_id     = (string) Tools::getValue('CSOFT_PLACEREVIEW_PLACE_ID');
        $apikey       = (string) Tools::getValue('CSOFT_PLACEREVIEW_KEY');
        $period       = (int) Tools::getValue('CSOFT_PLACEREVIEW_PERIODICITY');
        $rate         = (int) Tools::getValue('CSOFT_PLACEREVIEW_RATE');
        $title        = (int) Tools::getValue('CSOFT_PLACEREVIEW_TITLE');
        $cache_config = (string)Tools::getValue('CSOFT_PLACEREVIEW_CACHE_CONFIG');
        $font_choice  = (string)Tools::getValue('CSOFT_PLACEREVIEW_FONT_CHOICE');
        $cs_slideAuto = (int)Tools::getValue('CSOFT_PLACEREVIEW_SLIDE_AUTO');


        $output = '';

        if (Tools::isSubmit('searchButton')) {
            $status = $this->getGooglePlaceID($apikey);
            if ($status !== true) {
                $output = $status;
            } else {
                $output = $this->displayConfirmation($this->l('Settings updated'));
            }
        } else {
            if (Tools::isSubmit('submit' . $this->name)) {

                if (empty($apikey) || empty($place_id)) {
                    $output = $this->displayError($this->l('Invalid Configuration value'));
                } else {
                    $status = $this->verifyPlaceId($apikey, $place_id);

                    if ($status !== true) {
                        $output = $status;
                    } else {
                        Tools::clearCache(Context::getContext()->smarty, $this->getTemplatePath(($this->templateCsoftPlaceReviews), $this->getCacheId()));
						Tools::clearCache(Context::getContext()->smarty, $this->getTemplatePath('index.tpl'));
                        Configuration::updateValue('CSOFT_PLACEREVIEW_KEY', $apikey);
                        Configuration::updateValue('CSOFT_PLACEREVIEW_PLACE_ID', $place_id);
                        Configuration::updateValue('CSOFT_PLACEREVIEW_RATE', $rate);
                        Configuration::updateValue('CSOFT_PLACEREVIEW_PERIODICITY', $period);
                        Configuration::updateValue('CSOFT_PLACEREVIEW_TITLE', $title);
                        Configuration::updateValue('CSOFT_PLACEREVIEW_CACHE_CONFIG', $cache_config);
                        Configuration::updateValue('CSOFT_PLACEREVIEW_FONT_CHOICE', $font_choice);
                        Configuration::updateValue('CSOFT_PLACEREVIEW_SLIDE_AUTO', $cs_slideAuto);
                        Configuration::updateValue('CSOFT_PLACEREVIEW_FILTER', (int)Tools::getValue('CSOFT_PLACEREVIEW_FILTER'));

                        $output = $this->displayConfirmation($this->l('Settings updated'));
                    }
                }
            }
        }
        return $output . $this->displayForm();
    }

    private function cacheDuration()
    {
        $config_choice = Tools::getValue('CSOFT_PLACEREVIEW_CACHE_CONFIG');
        $cache_date = $this->getCacheId();

        if ($config_choice == 0) {
            $cache_date .= '|' . date("YmdH");
        } else {
            $cache_date .= '|' . date("Ymd");
        }

        return $cache_date;
    }

    private function _displayInfos()
    {
        $this->smarty->assign(array('moduleName' => $this->displayName, 
									'customer_name' => $this->context->employee->firstname . ' ' . substr($this->context->employee->lastname, 0, 1) . '.', 
									'module_review_path' => $this->module_review_path, 
									'product_shop_id' => $this->product_shop_id, 
									'domain' => urlencode(Context::getContext()->shop->getBaseURL(true)),
									'module_controller_url' => $this->module_controller_url));

        return $this->display(__FILE__, 'views/templates/admin/infos.tpl');
    }

    /**
     * Builds the configuration form
     * @return string HTML code
     */
    public function displayForm()
    {
        $place_id_list = json_decode(Configuration::get('CSOFT_PLACEREVIEW_PLACE_ID_LIST'));

        $form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Settings'),

                ],
                'description' => $this->l('To get your own Google API key, please get a Google account and click on the folowing link')
                    . ' <a href="https://console.cloud.google.com/?hl=fr" target="_blank">console.cloud.google.com</a>.<br/>'
                    . $this->l('After the account created, activate place API and create place Api key with IP restriction.') . '<br/><strong>'
                    . $this->l('BE CARREFUL, you must configure the restriction by IP with the server IP and not by HTTP otherwise this API does not work!') . '</strong><br/>'
                    . $this->l('Your server IP is : ') . $_SERVER['SERVER_ADDR'] . '<br/>' 
                    . $this->l('If the place id find with the automatic search is wrong, please check the shop address configuration.') . ' '
                    . $this->l('To define another place id without the automatic search, please click on the folowing link and enter the postal address or the shop name wished')
                    . '<br /><a href="https://developers.google.com/maps/documentation/places/web-service/place-id" target="_blank">https://developers.google.com/maps/documentation/places/web-service/place-id</a><br />',
                'buttons' => [[
                    'class' => 'btn btn-default pull-right',
                    'type' => 'submit',
                    'id'   => 'searchButton',
                    'name' => 'searchButton',
                    'icon' => 'icon-foo',
                    'title' => $this->l('search place id')
                ]],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('Key'),
                        'name' => 'CSOFT_PLACEREVIEW_KEY',
                        'required' => true,
                        'hint' =>  $this->l('Enter a Google API key.'),
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Place id'),
                        'name' => 'CSOFT_PLACEREVIEW_PLACE_ID',
                        'required' => true,
                        'desc' =>  '<i>' . $this->l('Enter your Place_ID if you know it, or click on the "search place id" button to obtain it automatically.') . '</i>',
                        'hint' =>  $this->l('Enter the desired place id or click on search button to find yours if you define the Google API key first.'),
                    ],
                    array(

                        'type'      => 'switch',
                        'label'     => $this->l('Title'),
                        'name'      => 'CSOFT_PLACEREVIEW_TITLE',
                        'required'  => true,
                        'class'     => 't',
                        'is_bool'   => true,
                        'values'    => array(
                            array(
                                'id'    => 'active_on',
                                'value' => 1,
                                'label' => $this->l('With')
                            ),
                            array(
                                'id'    => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Without')
                            )
                        ),
                        'hint' =>  $this->l('Show or hide the main title.'),
                    ),

                    array(

                        'type'      => 'switch',
                        'label'     => $this->l('Rate'),
                        'name'      => 'CSOFT_PLACEREVIEW_RATE',
                        'required'  => true,
                        'class'     => 't',
                        'is_bool'   => true,
                        'values'    => array(
                            array(
                                'id'    => 'active_on',
                                'value' => 1,
                                'label' => $this->l('With')
                            ),
                            array(
                                'id'    => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Without')
                            )
                        ),
                        'hint' =>  $this->l('Show or hide the rate.'),
                    ),
                    array(

                        'type'      => 'switch',
                        'label'     => $this->l('Periodicity'),
                        'name'      => 'CSOFT_PLACEREVIEW_PERIODICITY',
                        'required'  => true,
                        'class'     => 't',
                        'is_bool'   => true,
                        'values'    => array(
                            array(
                                'id'    => 'active_on',
                                'value' => 1,
                                'label' => $this->l('With')
                            ),
                            array(
                                'id'    => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Without')
                            )
                        ),
                        'hint' =>  $this->l('Show or hide the periodicity.'),
                    ),

                    array(
                        'type' => 'select',
                        'label' => $this->l('Filter'),
                        'name' => 'CSOFT_PLACEREVIEW_FILTER',
                        'hint' =>  $this->l('Choose which filter to get reviews.'),
                        'options' => array(
                            'query' => array(
                                array(
                                    'id' => '0',
                                    'name' => $this->l('The most recent')
                                ),
                                array(
                                    'id' => '1',
                                    'name' => $this->l('The most relevant')
                                ),
                            ),
                            'id' => 'id',
                            'name' => 'name'
                        ),
                    ),

                    array(
                        'type' => 'select',
                        'label' => $this->l('Cache duration'),
                        'name' => 'CSOFT_PLACEREVIEW_CACHE_CONFIG',
                        'hint' =>  $this->l('Choose the duration of the cache to update your display with new reviews.'),
                        'options' => array(
                            'query' => array(
                                array(
                                    'id' => '0',
                                    'name' => $this->l('Every hours')
                                ),
                                array(
                                    'id' => '1',
                                    'name' => $this->l('Every day')
                                ),
                            ),
                            'id' => 'id',
                            'name' => 'name'
                        ),
                    ),
                    array(

                        'type' => 'select',
                        'label' => $this->l('Font choice'),
                        'name' => 'CSOFT_PLACEREVIEW_FONT_CHOICE',
                        'hint' =>  $this->l('Choose the icon library you want in the slider.'),
                        'options' => array(
                            'query' => array(
                                array(
                                    'id' => '0',
                                    'name' => $this->l('Font Awesome')
                                ),
                                array(
                                    'id' => '1',
                                    'name' => $this->l('Material icon')
                                ),
                            ),
                            'id' => 'id',
                            'name' => 'name'
                        ),
                    ),
                    array(

                        'type'      => 'switch',
                        'label'     => $this->l('Slider auto'),
                        'name'      => 'CSOFT_PLACEREVIEW_SLIDE_AUTO',
                        'required'  => true,
                        'class'     => 't',
                        'is_bool'   => true,
                        'values'    => array(
                            array(
                                'id'    => 'Auto_slide_on',
                                'value' => 1,
                                'label' => $this->l('Yes')
                            ),
                            array(
                                'id'    => 'Auto_slide_off',
                                'value' => 0,
                                'label' => $this->l('No')
                            )
                        ),
                        'hint' =>  $this->l('Set the slider to autoplay'),
                    ),

                ],
                'submit' => [
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],

        ];
        if (is_array($place_id_list == true)) {
            count($place_id_list);
            $form['form']['input'][] =

                [
                    'type' => 'select',
                    'label' => $this->l('Select'),
                    'name' => 'CSOFT_PLACEREVIEW_PLACE_ID_LIST',
                    'required' => true,

                ];
        }

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->table = $this->table;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&' . http_build_query(['configure' => $this->name]);
        $helper->submit_action = 'submit' . $this->name;

        // Default language
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');

        $apikey = (string) Tools::getValue('CSOFT_PLACEREVIEW_KEY', Configuration::get('CSOFT_PLACEREVIEW_KEY'));
        if (Tools::isSubmit('searchButton') && (empty(Tools::getValue('CSOFT_PLACEREVIEW_PLACE_ID')) || $this->place_id != '')) {
            $place_id = Configuration::get('CSOFT_PLACEREVIEW_PLACE_ID');
        } else {
            $place_id = (string) Tools::getValue('CSOFT_PLACEREVIEW_PLACE_ID', Configuration::get('CSOFT_PLACEREVIEW_PLACE_ID'));
        }
        $rate = Tools::getValue('CSOFT_PLACEREVIEW_RATE', Configuration::get('CSOFT_PLACEREVIEW_RATE'));
        $period = Tools::getValue('CSOFT_PLACEREVIEW_PERIODICITY', Configuration::get('CSOFT_PLACEREVIEW_PERIODICITY'));
        $title = Tools::getValue('CSOFT_PLACEREVIEW_TITLE', Configuration::get('CSOFT_PLACEREVIEW_TITLE'));
        $cache_config = Tools::getValue('CSOFT_PLACEREVIEW_CACHE_CONFIG', Configuration::get('CSOFT_PLACEREVIEW_CACHE_CONFIG'));
        $font_choice = Tools::getValue('CSOFT_PLACEREVIEW_FONT_CHOICE', Configuration::get('CSOFT_PLACEREVIEW_FONT_CHOICE'));
        $cs_slideAuto = Tools::getValue('CSOFT_PLACEREVIEW_SLIDE_AUTO', Configuration::get('CSOFT_PLACEREVIEW_SLIDE_AUTO'));




        // Load current value into the form
        $helper->fields_value = [
            'CSOFT_PLACEREVIEW_KEY'             => $apikey,
            'CSOFT_PLACEREVIEW_PLACE_ID'        => $place_id,
            'CSOFT_PLACEREVIEW_RATE'            => $rate,
            'CSOFT_PLACEREVIEW_PERIODICITY'     => $period,
            'CSOFT_PLACEREVIEW_PLACE_ID_LIST'   => $place_id_list,
            'CSOFT_PLACEREVIEW_TITLE'           => $title,
            'CSOFT_PLACEREVIEW_CACHE_CONFIG'    => $cache_config,
            'CSOFT_PLACEREVIEW_FONT_CHOICE'     => $font_choice,
            'CSOFT_PLACEREVIEW_SLIDE_AUTO'     => $cs_slideAuto,
			'CSOFT_PLACEREVIEW_FILTER'		   => Tools::getValue('CSOFT_PLACEREVIEW_FILTER', Configuration::get('CSOFT_PLACEREVIEW_FILTER'))

        ];

        return $this->_displayInfos() . $helper->generateForm([$form]);
    }

    /**
     * Call api.
     *
     * @param string $apiType is for the switch case
     * @param string $place_id is determinated with api key and the global address
     * @param string $apikey is corresponding to the google api key
     * @param string $globalAdress is determinated with prestashop parameter.
     *
     * @return $data;
     */
    private function callApi($apiType, $place_id, $apikey, $globalAddress)
    {
        $namePlaceId = "details/json?place_id=$place_id";
        switch ($apiType) {
            case self::cVERIFYPLACEID:
                $param = $namePlaceId;
                break;
            case self::cGETREVIEWS:
				$filter = (Configuration::get('CSOFT_PLACEREVIEW_FILTER')==0) ? '&reviews_sort=newest' : '';
                $param = $namePlaceId . "&fields=name%2Crating%2Creviews&language=" . $this->context->language->iso_code . $filter;
                break;
            case self::cFINDPLACEID:
                $param = "findplacefromtext/json?input=$globalAddress&inputtype=textquery&fields=name%2Cplace_id";
                break;
        };
 
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_URL, "https://maps.googleapis.com/maps/api/place/$param&key=$apikey");
        $data = curl_exec($curl);
        curl_close($curl);

        return $data;
    }


    /**
     * Get Google Place ID.
     *
     * @param string $apikey is corresponding to the google api key
     * @return $output;
     */
    private function getGooglePlaceID($apikey)
    {
        $output = true;
        // si le champs key est vide
        if (empty($apikey)) {
            // renvoi un message d'erreur
            $output = $this->displayError($this->l('Please enter a valid Api key!'));
        } else {
            // sinon continu le traitement
            $addressContext = Context::getContext()->shop->getAddress();
            $addressPostal  = $addressContext->address1;
            $postCode       = $addressContext->postcode;
            $city           = $addressContext->city;
            $country        = Country::getNameById($this->context->language->id, $addressContext->id_country);
            $company        = $addressContext->company;


            $globalAdress = urlencode($company . ' ' . $addressPostal . ' ' . $postCode . ' ' . $city . ' ' . $country);

            $data = $this->callApi(self::cFINDPLACEID, null, $apikey, $globalAdress);
            if ($data === false) {
                $output = $this->displayError($this->l('Network error, cannot contact google services.'));
            } else {
                $data = json_decode($data, true);
                if ($data["status"] == 'OK') {
                    if (count($data["candidates"]) == 1) {
                        Configuration::updateValue('CSOFT_PLACEREVIEW_PLACE_ID', $data["candidates"][0]["place_id"]);
                        $this->place_id = $data["candidates"][0]["place_id"];
                        $dataName = $data["candidates"][0]["name"];
                        $output = $this->displayWarning(sprintf($this->l('The shop associate to the place id founded is : %s .
                        Please save now your configuration options by clicking Save button.'), $dataName));
                    } else {
                        Configuration::updateValue('CSOFT_PLACEREVIEW_PLACE_ID_LIST', json_encode($data["candidates"]));
                        $output = $this->displayError($this->l('To many place_id for this address, please select one.'));
                    }
                } else {
                    $error = '';
                    if($data["status"] != "ZERO_RESULTS"){
                        if (isset($data["error_message"])) {
                            $error = $data["error_message"];
                        }
                        $output = $this->displayError(sprintf($this->l('A api error occured: %s !'), $error));
                    }else{
                        $output = $this->displayError($this->l('There is no place ID find, please check the address enter in shop configuration / contact in shop tab.'));
                    }
                }
            }
        }
        return $output;
    }

    /**
     * Get Google Reviews
     *
     * @param string $apikey is corresponding to the google api key
     * @param string $place_id is corresponding to the google place id
     * @return $output;
     */
    public function getGoogleReviews($apikey, $place_id)
    {
        $output = false;
        $data = $this->callApi(self::cGETREVIEWS, $place_id, $apikey, null);

        if ($data !== false) {
            $data = json_decode($data, true);
            if ($data["status"] == 'OK') {
                $output = $data['result'];
            }
        }
        return $output;
    }

    /**
     * Verify place id.
     *
     * @param string $apikey is corresponding to the google api key
     * @param string $place_id is determinated with api key and the global address
     *
     * @return $output;
     */
    public function verifyPlaceId($apikey, $place_id)
    {
        $output = true;
        $data = $this->callApi(self::cVERIFYPLACEID, $place_id, $apikey, null);

        if ($data === false) {
            $output = $this->displayError($this->l('network error, cannot contact google services.'));
        } else {

            $data = json_decode($data, true);
            if ($data["status"] != 'OK') {
                if (isset($data["error_message"])) {

                    $error = $data['error_message'] . ' ' . $data['status'];
                } else {
                    $error = json_encode($data);
                }
                $output = $this->displayError(sprintf($this->l('A api error occured: %s !'), $error));
            }
        }
        return $output;
    }


    /**
     * Hook display home.
     *
     * @return template csoft_placeReviews.tpl;
     */
    public function hookDisplayHome($params)
    {
        return $this->renderWidget('displayHome', $params);
    }

    /**
     * Hook display header.
     * slide js for reviews
     * 
     * @return bxslider;
     */
    public function hookDisplayHeader()
    {
        $this->context->controller->addJqueryPlugin('bxslider');
    }
    /**
     * Hook Action Front Controller Set Media.
     * to modify css and js
     */
    public function hookActionFrontControllerSetMedia($params)
    {
        $this->context->controller->registerStylesheet(
            'placereviewsCss',
            'modules/' . $this->name . '/views/css/placereviews.css',
            [
                'media' => 'all',
                'priority' => 200,
            ]
        );

        $this->context->controller->registerJavascript(
            'placeReviewsjs',
            'modules/' . $this->name . '/views/js/cs_placeReviews.js',
            [
                'priority' => 200,
                'attribute' => 'async',
            ]
        );
        Media::addJsDef(array(
            'csoft_placereview_js' => array(
                'cs_slideAuto' => (int)Configuration::get('CSOFT_PLACEREVIEW_SLIDE_AUTO'),
            )
        ));
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addCSS($this->getPathUri() . '/views/css/productcomments.css');
            $this->context->controller->addJS($this->getPathUri() . '/views/js/jquery.rating.plugin.js');
            $this->context->controller->addJS($this->getPathUri() . '/views/js/post-comment.js');
        }
    }
}
